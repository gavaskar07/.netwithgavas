﻿namespace Student.Models
{
    public class Student1
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
        public static IList<Student1> display()
        {
            IList<Student1> studentList = new List<Student1>{
                new Student1() { StudentId = 1, StudentName = "John", Age = 18 } ,
                new Student1() { StudentId = 2, StudentName = "Steve",  Age = 21 } ,
                new Student1() { StudentId = 3, StudentName = "Bill",  Age = 25 } ,
                new Student1() { StudentId = 4, StudentName = "Ram" , Age = 20 } ,
                new Student1() { StudentId = 5, StudentName = "Ron" , Age = 31 } ,
                new Student1() { StudentId = 4, StudentName = "Chris" , Age = 17 } ,
                new Student1() { StudentId = 4, StudentName = "Rob" , Age = 19 }
            };
            return studentList;
        }
    }
}
